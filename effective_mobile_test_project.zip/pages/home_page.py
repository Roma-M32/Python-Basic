
from playwright.sync_api import Page

class HomePage:
    def __init__(self, page: Page):
        self.page = page
        self.about_us_link = 'a#about-us'
        self.contacts_link = 'a#contacts'

    def go_to_about_us(self):
        self.page.click(self.about_us_link)

    def go_to_contacts(self):
        self.page.click(self.contacts_link)

    def get_current_url(self):
        return self.page.url
