
# Проект для тестирования главной страницы

## Установка зависимостей

1. Клонируйте репозиторий:
   ```bash
   git clone https://github.com/your-repo.git
   cd your-repo
   ```

2. Установите зависимости:
   ```bash
   pip install -r requirements.txt
   ```

3. Установите Playwright:
   ```bash
   python -m playwright install
   ```

## Запуск тестов

1. Для запуска тестов локально:
   ```bash
   pytest
   ```

2. Для генерации отчетов Allure:
   ```bash
   pytest --alluredir=allure-results
   allure serve allure-results
   ```

## Запуск в Docker

1. Сборка Docker образа:
   ```bash
   docker build -t test-image .
   ```

2. Запуск тестов:
   ```bash
   docker run --rm test-image
   ```
