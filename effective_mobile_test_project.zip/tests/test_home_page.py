
import pytest
from playwright.sync_api import sync_playwright
from pages.home_page import HomePage

def test_navigation():
    with sync_playwright() as p:
        browser = p.chromium.launch()
        page = browser.new_page()
        home_page = HomePage(page)
        page.goto('https://effective-mobile.ru')

        # Проверка перехода по ссылке "О нас"
        home_page.go_to_about_us()
        assert home_page.get_current_url() == "https://effective-mobile.ru/about-us"
        
        # Проверка перехода по ссылке "Контакты"
        home_page.go_to_contacts()
        assert home_page.get_current_url() == "https://effective-mobile.ru/contacts"
        
        browser.close()
